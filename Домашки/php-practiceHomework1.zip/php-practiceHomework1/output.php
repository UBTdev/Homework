<span><?php $f = 'boob'?> <?php echo $f ?></span>
<?php
function myFirsFunction ($htmlTag, $number) {
    echo "$htmlTag $number";
};
myFirsFunction("<span>",'s 2');
?>